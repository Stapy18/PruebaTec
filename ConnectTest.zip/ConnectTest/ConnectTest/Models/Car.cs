﻿namespace ConnectTest.Models
{
    public class Car
    {
        public int ID { get; set; }

        public int Year { get; set; }

        public string? Make { get; set; }
        
        public string? Model { get; set; }
        
        public string? Color { get; set; }
        
        public string? Plate { get; set; }
        
        public string? VIN { get; set; }
    }

    public class ValidateCars
    {
        public List<Car> Cars { get; set;}

        public ValidateCars() 
        {
            Cars = new List<Car>
            {
                new Car { Year = 2020, Make = "Acura", Model = "TLX" },
                new Car { Year = 2020, Make = "Acura", Model = "RDX" },
                new Car { Year = 2019, Make = "Acura", Model = "ILX" },
                new Car { Year = 2019, Make = "Acura", Model = "MDX" },
                new Car { Year = 2019, Make = "Acura", Model = "NSX" },
                new Car { Year = 2018, Make = "BMW", Model = "2 SERIES" },
                new Car { Year = 2018, Make = "BMW", Model = "3 SERIES" }
            };
        }

        public bool ValidCar(Car car)
        {
            if (Cars is not null)
            {
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                var result = from r in Cars
                             where r.Year == car.Year &&
                                   r.Make.Equals(car.Make, StringComparison.OrdinalIgnoreCase) &&
                                   r.Model.Equals(car.Model, StringComparison.OrdinalIgnoreCase)
                             select r;
#pragma warning restore CS8602 // Dereference of a possibly null reference.

                if (result is not null && result.Any())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }            
        }

    }

}
